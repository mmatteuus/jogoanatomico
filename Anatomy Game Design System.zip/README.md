
  # Anatomy Game Design System

  This is a code bundle for Anatomy Game Design System. The original project is available at https://www.figma.com/design/QxjixvNzYdcEFaf5TMiQyX/Anatomy-Game-Design-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  